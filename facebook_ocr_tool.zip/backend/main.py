from fastapi import FastAPI, File, UploadFile
from fastapi.responses import JSONResponse, HTMLResponse
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import StreamingResponse
from typing import List
from PIL import Image
import pytesseract
from openai import OpenAI
import io
import os
import time

# Tesseractin polku Macilla
pytesseract.pytesseract.tesseract_cmd = "/opt/homebrew/bin/tesseract"

# OpenAI-asiakas
client = OpenAI(api_key="YOUR_OPENAI_API_KEY")

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

def clean_text(text):
    remove_keywords = ["Tykkää", "Kommentoi", "Jaa", "Katso lisää", "Näytä lisää", "·"]
    for word in remove_keywords:
        text = text.replace(word, "")
    return text.strip()

def anonymize_text(text):
    prompt = f"Anonymisoi ja stilisoi seuraava Facebook-teksti:\n\n{text}\n\nKorvaa nimet muotoon Henkilö 1, Henkilö 2 jne. ja poista kaikki tunnistettavat tiedot."
    response = client.chat.completions.create(
        model="gpt-4",
        messages=[
            {"role": "system", "content": "Olet avustaja, joka anonymisoi Facebook-julkaisuja poistamalla nimet ja turhat elementit."},
            {"role": "user", "content": prompt}
        ]
    )
    return response.choices[0].message.content.strip()

@app.post("/process-stream/")
async def process_images_stream(files: List[UploadFile] = File(...)):
    async def process():
        total = len(files)
        for i, file in enumerate(files):
            contents = await file.read()
            image = Image.open(io.BytesIO(contents))
            text = pytesseract.image_to_string(image, lang="fin")
            cleaned = clean_text(text)
            anonymized = anonymize_text(cleaned)

            yield f"--- Kuva {i+1}/{total} käsitelty ---\n"
            yield anonymized
            yield "\n\n"

    return StreamingResponse(process(), media_type="text/plain")

# Palvellaan frontend-kansio staattisesti
app.mount("/frontend", StaticFiles(directory="../frontend", html=True), name="frontend")

@app.get("/", response_class=HTMLResponse)
def serve_frontend():
    with open("../frontend/index.html", encoding="utf-8") as f:
        return f.read()
